package com.example.chidinmashp.a8queenpuzzlegame;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int queenCounter = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



    }
    Intent x = getIntent();


    boolean[][] queenOn = new boolean[9][8];


    public void gameFunction (View v) {



            switch (v.getId()) {
                case R.id.a1:
                    if (queenOn[1][0] == false) {
                        if (safe(1, 0) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[1][0] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[1][0] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.a2:
                    if (queenOn[1][1] == false) {
                        if (safe(1, 1) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[1][1] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[1][1] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.a3:
                    if (queenOn[1][2] == false) {
                        if (safe(1, 2) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[1][2] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[1][2] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.a4:
                    if (queenOn[1][3] == false) {
                        if (safe(1, 3) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[1][3] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[1][3] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.a5:
                    if (queenOn[1][4] == false) {
                        if (safe(1, 4) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[1][4] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[1][4] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.a6:
                    if (queenOn[1][5] == false) {
                        if (safe(1, 5) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[1][5] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[1][5] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.a7:
                    if (queenOn[1][6] == false) {
                        if (safe(1, 6) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[1][6] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[1][6] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.a8:
                    if (queenOn[1][7] == false) {
                        if (safe(1, 7) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[1][7] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[1][7] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.b1:
                    if (queenOn[2][0] == false) {
                        if (safe(2, 0) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[2][0] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[2][0] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.b2:
                    if (queenOn[2][1] == false) {
                        if (safe(2, 1) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[2][1] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[2][1] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.b3:
                    if (queenOn[2][2] == false) {
                        if (safe(2, 2) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[2][2] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[2][2] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.b4:
                    if (queenOn[2][3] == false) {
                        if (safe(2, 3) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[2][3] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[2][3] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.b5:
                    if (queenOn[2][4] == false) {
                        if (safe(2, 4) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[2][4] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[2][4] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.b6:
                    if (queenOn[2][5] == false) {
                        if (safe(2, 5) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[2][5] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[2][5] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.b7:
                    if (queenOn[2][6] == false) {
                        if (safe(2, 6) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[2][6] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[2][6] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.b8:
                    if (queenOn[2][7] == false) {
                        if (safe(2, 7) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[2][7] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[2][7] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.c1:
                    if (queenOn[3][0] == false) {
                        if (safe(3, 0) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[3][0] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[3][0] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.c2:
                    if (queenOn[3][1] == false) {
                        if (safe(3, 1) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[3][1] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[3][1] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.c3:
                    if (queenOn[3][2] == false) {
                        if (safe(3, 2) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[3][2] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[3][2] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.c4:
                    if (queenOn[3][3] == false) {
                        if (safe(3, 3) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[3][3] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[3][3] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.c5:
                    if (queenOn[3][4] == false) {
                        if (safe(3, 4) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[3][4] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[3][4] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.c6:
                    if (queenOn[3][5] == false) {
                        if (safe(3, 5) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[3][5] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[3][5] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.c7:
                    if (queenOn[3][6] == false) {
                        if (safe(3, 6) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[3][6] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[3][6] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.c8:
                    if (queenOn[3][7] == false) {
                        if (safe(3, 7) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[3][7] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[3][7] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.d1:
                    if (queenOn[4][0] == false) {
                        if (safe(4, 0) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[4][0] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[4][0] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.d2:
                    if (queenOn[4][1] == false) {
                        if (safe(4, 1) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[4][1] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[4][1] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.d3:
                    if (queenOn[4][2] == false) {
                        if (safe(4, 2) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[4][2] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[4][2] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.d4:
                    if (queenOn[4][3] == false) {
                        if (safe(4, 3) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[4][3] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[4][3] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.d5:
                    if (queenOn[4][4] == false) {
                        if (safe(4, 4) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[4][4] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[4][4] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.d6:
                    if (queenOn[4][5] == false) {
                        if (safe(4, 5) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[4][5] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[4][5] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.d7:
                    if (queenOn[4][6] == false) {
                        if (safe(4, 6) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[4][6] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[4][6] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.d8:
                    if (queenOn[4][7] == false) {
                        if (safe(4, 7) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[4][7] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[4][7] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.e1:
                    if (queenOn[5][0] == false) {
                        if (safe(5, 0) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[5][0] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[5][0] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.e2:
                    if (queenOn[5][1] == false) {
                        if (safe(5, 1) != true) {

                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[5][1] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[5][1] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.e3:
                    if (queenOn[5][2] == false) {
                        if (safe(5, 2) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[5][2] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[5][2] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.e4:
                    if (queenOn[5][3] == false) {
                        if (safe(5, 3) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[5][3] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[5][3] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.e5:
                    if (queenOn[5][4] == false) {
                        if (safe(5, 4) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[5][4] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[5][4] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.e6:
                    if (queenOn[5][5] == false) {
                        if (safe(5, 5) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[5][5] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[5][5] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.e7:
                    if (queenOn[5][6] == false) {
                        if (safe(5, 6) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[5][6] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[5][6] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.e8:
                    if (queenOn[5][7] == false) {
                        if (safe(5, 7) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[5][7] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[5][7] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.f1:
                    if (queenOn[6][0] == false) {
                        if (safe(6, 0) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[6][0] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[6][0] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.f2:
                    if (queenOn[6][1] == false) {
                        if (safe(6, 1) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[6][1] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[6][1] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.f3:
                    if (queenOn[6][2] == false) {
                        if (safe(6, 2) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[6][2] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[6][2] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.f4:
                    if (queenOn[6][3] == false) {
                        if (safe(6, 3) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[6][3] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[6][3] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.f5:
                    if (queenOn[6][4] == false) {
                        if (safe(6, 4) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[6][4] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[6][4] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.f6:
                    if (queenOn[6][5] == false) {
                        if (safe(6, 5) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[6][5] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[6][5] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.f7:
                    if (queenOn[6][6] == false) {
                        if (safe(6, 6) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[6][6] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[6][6] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.f8:
                    if (queenOn[6][7] == false) {
                        if (safe(6, 7) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[6][7] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[6][7] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.g1:
                    if (queenOn[7][0] == false) {
                        if (safe(7, 0) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[7][0] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[7][0] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.g2:
                    if (queenOn[7][1] == false) {
                        if (safe(7, 1) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[7][1] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[7][1] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.g3:
                    if (queenOn[7][2] == false) {
                        if (safe(7, 2) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[7][2] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[7][2] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.g4:
                    if (queenOn[7][3] == false) {
                        if (safe(7, 3) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[7][3] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[7][3] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.g5:
                    if (queenOn[7][4] == false) {
                        if (safe(7, 4) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[7][4] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[7][4] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.g6:
                    if (queenOn[7][5] == false) {
                        if (safe(7, 5) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[7][5] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[7][5] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.g7:
                    if (queenOn[7][6] == false) {
                        if (safe(7, 6) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[7][6] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[7][6] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.g8:
                    if (queenOn[7][7] == false) {
                        if (safe(7, 7) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[7][7] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[7][7] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.h1:
                    if (queenOn[8][0] == false) {
                        if (safe(8, 0) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[8][0] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[8][0] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.h2:
                    if (queenOn[8][1] == false) {
                        if (safe(8, 1) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[8][1] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[8][1] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.h3:
                    if (queenOn[8][2] == false) {
                        if (safe(8, 2) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[8][2] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[8][2] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.h4:
                    if (queenOn[8][3] == false) {
                        if (safe(8, 3) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[8][3] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[8][3] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.h5:
                    if (queenOn[8][4] == false) {
                        if (safe(8, 4) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[8][4] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[8][4] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.h6:
                    if (queenOn[8][5] == false) {
                        if (safe(8, 5) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[8][5] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[8][5] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.h7:
                    if (queenOn[8][6] == false) {
                        if (safe(8, 6) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[8][6] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.gray);
                        queenOn[8][6] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.h8:
                    if (queenOn[8][7] == false) {
                        if (safe(8, 7) != true) {
                            Toast.makeText(this, "WRONG", Toast.LENGTH_SHORT).show();
                        } else {
                            v.setBackgroundResource(R.drawable.chessqueen);
                            queenOn[8][7] = true;
                            queenCounter++;
                        }
                    } else {
                        //change square back
                        v.setBackgroundResource(R.drawable.blue);
                        queenOn[8][7] = false;
                        queenCounter--;
                    }
                    break;
                case R.id.restart:
                    this.recreate();
                    break;
                default:
                    break;

            }
        if (queenCounter == 8) {
            Intent game_win = new Intent(this, Win.class);
            startActivity(game_win);
        }
        }



    public boolean safe(int x, int y){
        boolean rowCheck = true;
        boolean colCheck = true;
        boolean diaCheck = true;

        //do row check
        for(int i = 1; i < 9; i++){
            if(queenOn[i][y]== true){
                rowCheck = false;
            }
        }
        //do col check
        for(int j = 0; j < 8; j++){
            if(queenOn[x][j]== true){
                colCheck = false;
            }
        }

        //do diagonal check
        //x+, y-
       int lowery = y-1;
        for(int lx = x-1; lx >= 1 && lowery >=0; lx--){
            if(queenOn[lx][lowery] == true){
                diaCheck = false;
            }
            lowery--;
            }
        //x-, y-
        int uppery = y+1;
        for(int ux = x-1; ux >= 1 && uppery <= 7; ux--){
            if(queenOn[ux][uppery] == true){
                diaCheck = false;
            }
            uppery++;
            }
        //x+, y-
        int lowerx = x+1;
        for(int ly = y-1; ly >=0 && lowerx <=8; ly--){
            if(queenOn[lowerx][ly] == true) {
                diaCheck = false;
            }
            lowerx++;
        }
       //same as one above //x+, y-
       int upperx = x+1;
        for(int uy = y+1; uy <=7 && upperx <=8; uy++){
            if(queenOn[upperx][uy] == true){
                diaCheck = false;
            }
            upperx++;
        }

        if(rowCheck == false || colCheck == false || diaCheck == false){
            return false;
        }else{
            return true;
        }

    }
}
