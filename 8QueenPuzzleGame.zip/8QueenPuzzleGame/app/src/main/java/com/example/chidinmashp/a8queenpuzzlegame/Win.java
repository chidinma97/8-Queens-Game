package com.example.chidinmashp.a8queenpuzzlegame;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

/**
 * Created by Chidinma's HP on 9/5/2017.
 */

public class Win extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.win_game);
    }

    public void mainPage(View v){
        Intent goback = new Intent(this, MainActivity.class);
        startActivity(goback);
    }
}
